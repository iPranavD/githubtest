#pragma once
#include "main.h"

// Autonomous routine functions
void rightSideAuton();
void deuxauto();
void skillsAuton();
void defaultAuton();

// Helper functions for autonomous
void deployIntake();
void scoreBasket();