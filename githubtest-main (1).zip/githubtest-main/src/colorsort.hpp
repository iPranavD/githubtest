#pragma once
#include "main.h"


void setIntakeTop();
void setMidScoring();
void setHighScoring();
void setLowScoring();
void setIdle();

