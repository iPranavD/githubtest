#include "main.h"
#include "config.hpp"
#include "colorsort.hpp"
#include "autons.hpp"

#include <array>
#include <iostream>

// Position selector options
enum class StartPosition {
    RED_RIGHT,
    RED_LEFT,
    BLUE_RIGHT,
    BLUE_LEFT
};

StartPosition selectedPosition = StartPosition::RED_RIGHT; // Default
bool positionSelected = false;

void showPositionSelectorOnce() {
    if (positionSelected) return;
    const char* positions[4] = {"Red Right", "Red Left", "Blue Right", "Blue Left"};
    int current = 0;
    bool selected = false;
    controller.print(0, 0, "Select Start:");
    controller.print(1, 0, "%s", positions[current]);
    while (!selected) {
        // Only update line 1 for selection
        controller.print(1, 0, "%s", positions[current]);
        // Up/Down or Left/Right to change selection
        if (controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_UP) ||
            controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_RIGHT)) {
            current = (current + 1) % 4;
            pros::delay(150); // debounce
        } else if (controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_DOWN) ||
                   controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_LEFT)) {
            current = (current - 1 + 4) % 4;
            pros::delay(150); // debounce
        }
        // A to select
        if (controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_A)) {
            selected = true;
            selectedPosition = static_cast<StartPosition>(current);
            positionSelected = true;
        }
        pros::delay(50);
    }
}
/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
void initialize() {
    // Initialize hardware
    initializeHardware();
    // Initialize color sorting system
    

    printf("Robot initialization complete\n");

    // Thread for brain screen and position logging
    pros::Task screenTask([&]() {
        while (true) {
            // Print robot location to the brain screen
            pros::lcd::print(0, "X: %f", chassis.getPose().x); // x
            pros::lcd::print(1, "Y: %f", chassis.getPose().y); // y
            pros::lcd::print(2, "Theta: %f", chassis.getPose().theta); // heading
            // Log position telemetry
            lemlib::telemetrySink()->info("Chassis pose: {}", chassis.getPose());
            // Delay to save resources
            pros::delay(50);
        }
    });
    //showPositionSelectorOnce(); // Comment out to skip position selection
}

/**
 * Runs while the robot is disabled
 */
void disabled() {}

/**
 * Runs after initialize if the robot is connected to field control
 */
void competition_initialize() {
    
}

/**
 * Runs during autonomous period
 */
void autonomous() {
    //defaultAuton();
    //deuxauto();
    // Alternative: use different autons 
    rightSideAuton();
    // blueSideAuton();
    // skillsAuton();
}

/**
 * Runs in driver control
 */
void opcontrol() {
    printf("Driver control started\n");
    
    // Loop forever
    while (true) {
        bool park_toggle = false;
        const int lateral_power = controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y); 
        const int linear_power = 0 - controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_X); 
        chassis.arcade(lateral_power, linear_power);

        // Pull odom wheels automatically when approaching parking zone
        
        // Intake controls with color sorting 
        if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L1)) {
            setIntakeTop();
            mid_scoring.set_value(true);
        }
        else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
            setMidScoring();
            mid_scoring.set_value(false);
        }
        else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1)) {
            setHighScoring();
            mid_scoring.set_value(true);
        }
        else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2)) {
            setLowScoring();
            mid_scoring.set_value(true);
        }
        else {
            setIdle();
            mid_scoring.set_value(true);
    
        }
        

        if(park_toggle){
            instapark.set_value(true);
        }
        else{
            instapark.set_value(false);
        }
        if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_B)){
            while(dist.get() > 170){
                bottomrollers.move_velocity(-450.);
                toprollers.move_velocity(-150);
            }
            pros::delay(95);
            instapark.set_value(true);
            bottomrollers.move_velocity(0);
            toprollers.move_velocity(0);
            pros::delay(100000);
        }
    
        // Color mode toggle
        // Delay to save resources
        pros::delay(25);
    }
}
