#include "autons.hpp"
#include "config.hpp"
#include "colorsort.hpp"

// Get path asset (put this outside functions)
ASSET(example_txt); // '.' replaced with "_" to make c++ happy
//yo
/**
 * Helper function to deploy intake and start color sorting
 */

/**
 * Red side autonomous routine
 */
void rightSideAuton() {
    chassis.setPose(0, 0, 0);
    printf("Starting Red Side Autonomous\n");
    moveToPoint(0, 10, 0);`
    
    chassis.turnToHeading(90, 1000); 
}

/**
 * Blue side autonomous routine
 */
void deuxauto() {
    chassis.setPose(0, 0, 0);
    printf("Starting Blue Side Autonomous\n");
    
    // Set color mode for red alliance (change as needed)
    
    // Start intake with color sorting
    setIntakeTop();
    chassis.moveToPose(0, 40, 0, 3000);
    chassis.moveToPose(-13, 40, -59, 3000);
    pros::delay(4000);
    /*chassis.turnToHeading(180, 2000);
    scraper.set_value(true);
    chassis.moveToPoint(39, 0, 2000);xddd
    pros::delay(2500);
    scraper.set_value(false);
    chassis.moveToPoint(39, 5, 2000);*/
    setLowScoring();
  
    
    printf("Default Autonomous Complete\n");
}

/**
 * Skills autonomous routine
 */
void skillsAuton() {
    chassis.setPose(0, 0, 0);
    printf("Starting Skills Autonomous\n");

    chassis.moveToPose()
    chassis.moveToPose(50, -10, 100, 4000, {.maxspeed = }); //intake 3 balls on left side of field
    chassis.turnToHeading(245, 2000); //turn towards matchloader
    scraper.set_value(true); //put down scraper
    chassis.moveToPose(0, -30, 270, 4000); //drive to matchloader
    chassis.moveToPose(10, -30, 270, 1000, {.forwards = false}); //back up
    chassis.moveToPose(0, -30, 270, 1000); //drive back into matchloader

}

/**
 * Default autonomous routine (same as original)
 */
void defaultAuton() {
    printf("Starting Default Autonomous\n");
    
    // Set color mode for red alliance (change as needed)
    setIntakeTop();
    chassis.moveToPose(5, 29, 5, 2000);
    chassis.turnToHeading(135, 2000);
    chassis.moveToPoint(29, 5, 2000);
    chassis.turnToHeading(180, 2000);
    chassis.moveToPoint(29, -3, 2000, {.forwards = false});
    setHighScoring();


    

  
    
    printf("Default Autonomous Complete\n");

}